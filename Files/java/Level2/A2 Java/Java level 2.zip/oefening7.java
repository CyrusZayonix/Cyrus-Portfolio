
public class oefening7 {

}