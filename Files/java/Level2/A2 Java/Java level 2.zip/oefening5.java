public class oefening5 {
        
    
}
